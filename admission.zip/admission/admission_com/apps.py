from django.apps import AppConfig


class AdmissionComConfig(AppConfig):
    name = 'admission_com'

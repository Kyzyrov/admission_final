from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Teacher(models.Model):
    name = models.CharField(max_length=255, null=True)
    surname = models.CharField(max_length=255, null=True)
    degree = models.CharField(max_length=255, null=True)
    communication_link = models.CharField(max_length=255, null=True)
    # photo = models.ImageField(upload_to="photos/%Y/%m/%d/")
    date_created = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.name

class Student(models.Model):
    name = models.CharField(max_length=255, null=True)
    surname = models.CharField(max_length=255, null=True)
    dob = models.DateField(null=True)
    date_created = models.DateTimeField(auto_now_add = True, null=True)

    def __str__(self):
        return self.name

class Groups(models.Model):
    name = models.CharField(max_length = 255, null=True)
    student = models.ForeignKey(Student, null=True, on_delete=models.SET_NULL)
    teacher = models.ForeignKey(Teacher, null=True, on_delete=models.SET_NULL)
    date_created = models.DateTimeField(auto_now_add = True, null=True)
    def __str__(self):
        return self.name

class MasterStudents(models.Model):
    name = models.CharField(max_length=255, null=True)
    surname = models.CharField(max_length=255, null=True)
    dob = models.DateField(null=True)
    date_created = models.DateTimeField(auto_now_add = True, null=True)

    def __str__(self):
        return self.name

class DoctoralStudents(models.Model):
    name = models.CharField(max_length=255, null=True)
    surname = models.CharField(max_length=255, null=True)
    dob = models.DateField(null=True)
    date_created = models.DateTimeField(auto_now_add = True, null=True)

    def __str__(self):
        return self.name
from django.contrib import admin
from .models import *
admin.site.register(Teacher)
admin.site.register(Student)
admin.site.register(Groups)
admin.site.register(MasterStudents)
admin.site.register(DoctoralStudents)

# Register your models here.

from django.shortcuts import render, redirect
from .forms import *
from .models import *
from django.shortcuts import get_object_or_404
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import StudentsSerializer
from .serializers import TeachersSerializer
from django.core.cache import cache
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
# Create your views here.

@login_required(login_url = 'loginpage')
def home(request):
    return render(request,'home.html');

def about(request):
    return render(request, 'info.html');

def registration(request):
    form = CreateUserForm()

    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('authorization.html')
    context = {'form':form}
    return render(request, 'registration.html', context);

def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username = username, password = password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username or Password is incorrect')

    context={}
    return render(request, 'authorization.html', context);

def logoutUser(request):
    logout(request)
    return redirect('home')


def viewDataBase(request):
    teachers = Teacher.objects.all()
    print(teachers)
    teacher = Teacher.objects.values_list('id', flat=True)
    print(teacher)


    groups = Groups.objects.all()
    context = {'groups':groups, 'teachers':teachers,'teacher':teacher}
    return render(request, 'viewDataBase.html',context);

def students(request):
    students = cache.get('students')
    if not students:
        students = Student.objects.all()
    return render(request, "students.html", {'students':students})

def teachers(request):
    teachers = Teacher.objects.all()
    return render(request, "teachers.html", {'teachers':teachers})

def addGroups(request):
    form = GroupsForm()
    if request.method == 'POST':
        form = GroupsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('viewDataBase')

    context = {'form':form}
    return render(request, "addGroups.html", context)

def addTeachers(request):
    form = TeacherForm()
    if request.method == 'POST':
        form = TeacherForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('viewDataBase')

    context = {'form':form}
    return render(request, "addGroups.html", context)

def addStudents(request):
    form = StudentForm()
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('viewDataBase')

    context = {'form':form}
    return render(request, "addGroups.html", context)

def updateGroups(request, pk):
    groups = Groups.objects.get(id=pk)
    form = GroupsForm(instance = group)

    if request.method == 'POST':
        form = GroupsForm(request.POST, instance = group)
        if form.is_valid():
            form.save()
            return redirect('/')

    context = {'form': form}
    return render(request, "addGroups.html", context)
# @login_required(login_url = 'login')
def updateTeachers(request, id):
    id = request.POST.get(teacher_id)
    form = TeacherForm(instance = teacher)
    if request.method == 'POST':
        form = TeacherForm(request.POST, instance = teachers)
        if form.is_valid():
            edited_teacher = form.save(commit=False)
            teacher.save()
            return redirect('/')
        else:
            form = TeacherForm()
        return render(request, "addTeachers.html", {'form': form})

def update_view(request, id):
    context = {}
    obj = get_object_or_404(Groups, id = self.kwargs['id'])
    form = GroupsForm(request.POST, instance = obj)
    if form.is_valid():
        form.save()
        return redirect('/')
    context['form'] = form
    return render(request, "addGroups.html", context)

def delete(request,id):
    groups = Groups.objects.get(id=id)
    if request.method == 'POST':
        groups.delete()
        return redirect('/')
    context = {'item':groups}
    return render(request, 'delete.html', context)

def delete_teacher(request, id):
    teacher = Teacher.objects.get(id = id)
    print('Hello HelloHelloHelloHelloHelloHelloHelloHelloHelloHelloHelloHelloHello', teacher)
    context = {'item':teachers}
    Teacher.objects.get(id=teacher.id).delete()

    return render(request, 'viewDataBase', context)

class StudentsView(APIView):
    def get(self, request):
        students1 = Student.objects.all()
        teachers1 = Teacher.objects.all()
        serializer = StudentsSerializer(students1, many = True)
        serializer1 = TeachersSerializer(teachers1, many=True)
        return Response({"students1": serializer.data,"teacher1": serializer1.data})

    def post(self,request):
        students2 = request.data.get('students2')

        serializer = StudentsSerializer(data = students2)
        if serializer.is_valid(raise_exception = True):
            student_saved = serializer.save()
        return Response({"success":"Student '{}' added successfully".format(student_saved.name)})

    def put(self, request, pk):
        saved_students = get_object_or_404(Student.objects.all(), pk=pk)
        data = request.data.get('students1')
        serializer = ArticleSerializer(instance=saved_students, data=data, partial=True)
        if serializer.is_valid(raise_exception=True):
            students_saved = serializer.save()
        return Response({
            "success": "Student '{}' updated successfully".format(students_saved.name)
        })

    def delete(self, request, pk):
        # Get object with this pk
        students1 = get_object_or_404(Student.objects.all(), pk=pk)
        students1.delete()
        return Response({
            "message": "Student with id `{}` has been deleted.".format(pk)
        }, status=204)

    # class RegisterUser(DataMixin, CreateView):
    #     form_class = UserCreationForm
    #     template_name = 'registration.html'
    #     success_url = reverse_lazy('login')
    #
    #     def get_context_data(self, *, object_list = None, **kwargs):
    #         context = super().get_context_data(**kwargs)
    #         c_def = self.get_context_data(title='Registration')
    #         return dict(list(context.items()) + list()(c_def.items()))
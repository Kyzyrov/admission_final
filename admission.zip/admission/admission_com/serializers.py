from rest_framework import serializers
from .models import *


class StudentsSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=255)
    surname = serializers.CharField(max_length=255)
    dob = serializers.DateField()
    # date_created = serializers.DateTimeField()

    def create(self, data):
        return Student.objects.create(**data)

    def update(self, instance, data):
        instance.name = data.get('name', instance.name)
        instance.surname = data.get('surname', instance.surname)
        instance.dob = data.get('dob', instance.dob)

        instance.save()
        return instance

class TeachersSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=255)
    surname = serializers.CharField(max_length=255)
    degree = serializers.CharField(max_length=255)
    communication_link = serializers.CharField(max_length=255)
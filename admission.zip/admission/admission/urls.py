"""admission URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from admission_com import views
from django.conf.urls.static import static
from django.conf import settings
from django.db import models
from django.contrib.auth.models import User
from django.views.decorators.cache import cache_page

urlpatterns = [
    path('admin/', admin.site.urls),
    url('^$',views.home,name = 'home'),
    url('home',views.home,name = 'home'),
    url('about',views.about,name='about'),
    url('registration',views.registration,name='registration'),
    url('loginpage',views.loginPage,name='loginpage'),
    url('logout',views.logoutUser,name='logout'),
    url('viewDataBase', cache_page(60)(views.viewDataBase), name='viewDataBase'),
    url('students', views.students, name='students'),
    url('teachers', views.teachers, name='teachers'),
    url('addGroups', views.addGroups, name='addGroups'),
    url('addTeachers', views.addTeachers, name='addTeachers'),
    url('addStudents', views.addStudents, name='addStudents'),
    url('helloworld',views.StudentsView.as_view(), name='helloworld'),
    url('studentsOne/<int:pk>', views.StudentsView.as_view(), name='students1int'),


    url('updateGroups/<str:pk>/', views.updateGroups, name='updateGroups'),
    url('<teacher_id>/updateTeachers', views.updateTeachers, name='updateTeachers'),
    url('<id>/update', views.update_view, name = 'update'),
    url('delete', views.delete_teacher, name='delete_teacher'),
    url('<id>/delete', views.delete, name='delete')
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)